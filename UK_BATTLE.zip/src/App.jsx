
import React, { useEffect, useState } from 'react';
import { saveAs } from 'file-saver';

// Local storage hook
const useLocalState = (key, initial) => {
  const [state, setState] = useState(() => {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : initial; } catch { return initial; }
  });
  useEffect(() => { localStorage.setItem(key, JSON.stringify(state)); }, [key, state]);
  return [state, setState];
};

export default function App(){
  const [players, setPlayers] = useLocalState('players', []);
  const [teams, setTeams] = useLocalState('teams', []);
  const [matches, setMatches] = useLocalState('matches', []);
  const [announcements, setAnnouncements] = useLocalState('announcements', []);
  const [adminMode, setAdminMode] = useState(false);
  const ADMIN_PASS = 'admin123';

  const [form, setForm] = useState({name:'', team:'', game:''});

  const addPlayer = (e)=>{
    e.preventDefault();
    if(!form.name || !form.team || !form.game) return alert('Fill all fields');
    if(!teams.find(t=>t.name===form.team)){
      setTeams([...teams, {name: form.team, game: form.game}]);
    }
    setPlayers([...players, {...form, id: Date.now()}]);
    setForm({name:'', team:'', game:''});
  };

  const addMatch = (m)=> setMatches([...matches, {...m, id: Date.now()}]);
  const recordResult = (id, result)=> setMatches(matches.map(m=> m.id===id? {...m, result}:m));

  const leaderboard = (()=>{
    const map = {};
    teams.forEach(t=> map[t.name] = {team: t.name, played:0, won:0, lost:0, points:0, scoreFor:0, scoreAgainst:0});
    matches.forEach(m=>{
      if(!m.result) return;
      const A = map[m.teamA]; const B = map[m.teamB];
      if(!A||!B) return;
      A.played++; B.played++;
      A.scoreFor += Number(m.result.scoreA||0); A.scoreAgainst += Number(m.result.scoreB||0);
      B.scoreFor += Number(m.result.scoreB||0); B.scoreAgainst += Number(m.result.scoreA||0);
      if(m.result.winner===m.teamA){ A.won++; B.lost++; A.points += 3; }
      else if(m.result.winner===m.teamB){ B.won++; A.lost++; B.points += 3; }
      else { A.points += 1; B.points += 1; }
    });
    return Object.values(map).sort((a,b)=> b.points - a.points || (b.scoreFor - b.scoreAgainst) - (a.scoreFor - a.scoreAgainst));
  })();

  // Export / Import
  const exportJSON = ()=>{
    const blob = new Blob([JSON.stringify({players, teams, matches, announcements}, null, 2)], {type: 'application/json'});
    saveAs(blob, 'tournament-data.json');
  };
  const importJSON = (file)=>{
    const reader = new FileReader();
    reader.onload = ()=>{
      try{
        const data = JSON.parse(reader.result);
        if(data.players) setPlayers(data.players);
        if(data.teams) setTeams(data.teams);
        if(data.matches) setMatches(data.matches);
        if(data.announcements) setAnnouncements(data.announcements);
        alert('Imported');
      }catch(e){ alert('Invalid file'); }
    };
    reader.readAsText(file);
  };

  const exportPlayersCSV = ()=>{
    const header = ['id','name','team','game'];
    const rows = players.map(p=> [p.id, p.name, p.team, p.game].map(v=> '"'+String(v).replace(/"/g,'""')+'"').join(','));
    const csv = [header.join(','), ...rows].join('\n');
    const blob = new Blob([csv], {type:'text/csv'});
    saveAs(blob, 'players.csv');
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">🎮 UK BATTLE - Tournament Manager</h1>
          <div className="space-x-2">
            <button onClick={()=>{const pass=prompt('Enter admin password'); if(pass===ADMIN_PASS) setAdminMode(true); else alert('Wrong password');}} className="px-3 py-1 rounded bg-blue-600 text-white">Admin</button>
            <button onClick={()=>{ setPlayers([]); setTeams([]); setMatches([]); setAnnouncements([]); localStorage.clear(); }} className="px-3 py-1 rounded bg-red-500 text-white">Reset All</button>
          </div>
        </header>

        <main className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <section className="col-span-1 md:col-span-1 bg-white p-4 rounded shadow">
            <h2 className="font-semibold mb-2">Register Player</h2>
            <form onSubmit={addPlayer} className="space-y-2">
              <input className="w-full p-2 border rounded" placeholder="Player name" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
              <input className="w-full p-2 border rounded" placeholder="Team name" value={form.team} onChange={e=>setForm({...form, team:e.target.value})} />
              <input className="w-full p-2 border rounded" placeholder="Game" value={form.game} onChange={e=>setForm({...form, game:e.target.value})} />
              <button className="w-full bg-green-600 text-white p-2 rounded">Register</button>
            </form>

            <div className="mt-4">
              <h3 className="font-medium">Quick actions</h3>
              <div className="flex gap-2 mt-2">
                <button onClick={exportPlayersCSV} className="px-2 py-1 bg-indigo-600 text-white rounded">Export Players CSV</button>
                <label className="px-2 py-1 bg-gray-200 rounded cursor-pointer">
                  Import JSON
                  <input type="file" accept="application/json" onChange={e=>importJSON(e.target.files[0])} className="hidden" />
                </label>
                <button onClick={exportJSON} className="px-2 py-1 bg-gray-800 text-white rounded">Export All JSON</button>
              </div>
            </div>
          </section>

          <section className="col-span-1 md:col-span-1 bg-white p-4 rounded shadow">
            <h2 className="font-semibold mb-2">Teams & Matches</h2>
            <div className="space-y-3">
              <div>
                <h4 className="font-medium">Teams ({teams.length})</h4>
                <ul className="mt-2 space-y-1 max-h-36 overflow-auto">
                  {teams.map((t, i)=> <li key={i} className="p-2 border rounded">{t.name} — {t.game}</li>)}
                </ul>
              </div>

              <div>
                <h4 className="font-medium">Schedule</h4>
                <MatchCreator teams={teams} onCreate={addMatch} adminMode={adminMode} />
                <ul className="mt-2 space-y-2 max-h-40 overflow-auto">
                  {matches.map(m=> (
                    <li key={m.id} className="p-2 border rounded">
                      <div className="flex justify-between">
                        <div>
                          <div className="font-medium">{m.teamA} vs {m.teamB}</div>
                          <div className="text-sm">Date: {m.date}</div>
                          {m.result ? (
                            <div className="text-sm">Result: {m.result.winner} ({m.result.scoreA} - {m.result.scoreB})</div>
                          ) : <div className="text-sm">No result yet</div>}
                        </div>
                        {adminMode && (
                          <div className="flex flex-col gap-1">
                            <RecordResult match={m} onSave={recordResult} />
                          </div>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </section>

          <section className="col-span-1 md:col-span-1 bg-white p-4 rounded shadow">
            <h2 className="font-semibold mb-2">Leaderboard</h2>
            <ol className="space-y-2">
              {leaderboard.map((l,i)=> (
                <li key={i} className="p-2 border rounded flex justify-between">
                  <div>
                    <div className="font-medium">{l.team}</div>
                    <div className="text-sm">P:{l.played} W:{l.won} L:{l.lost} GF:{l.scoreFor} GA:{l.scoreAgainst}</div>
                  </div>
                  <div className="text-xl font-bold">{l.points}</div>
                </li>
              ))}
            </ol>

            <div className="mt-4">
              <h4 className="font-medium">Announcements</h4>
              <ul className="mt-2 space-y-2">
                {announcements.map((a, idx)=> <li key={idx} className="p-2 border rounded">{a}</li>)}
              </ul>
              {adminMode && (
                <AnnouncementEditor announcements={announcements} setAnnouncements={setAnnouncements} />
              )}
            </div>
          </section>
        </main>

        <footer className="mt-6 text-center text-sm text-gray-600">Made with ❤️ — change admin password and host on Netlify/Vercel when ready.</footer>
      </div>
    </div>
  );
}

function MatchCreator({teams, onCreate, adminMode}){
  const [tA, setTA] = useState(teams[0]?.name||'');
  const [tB, setTB] = useState(teams[1]?.name||'');
  const [date, setDate] = useState('');
  useEffect(()=>{ if(teams.length>=2){ setTA(teams[0].name); setTB(teams[1].name); } }, [teams]);
  const create = ()=>{ if(!adminMode) return alert('Admin only'); if(!tA || !tB || tA===tB) return alert('Select two different teams'); onCreate({teamA: tA, teamB: tB, date}); setDate(''); };
  return (
    <div className="space-y-2">
      <div className="flex gap-2">
        <select value={tA} onChange={e=>setTA(e.target.value)} className="flex-1 p-2 border rounded">
          {teams.map(t=> <option key={t.name} value={t.name}>{t.name}</option>)}
        </select>
        <select value={tB} onChange={e=>setTB(e.target.value)} className="flex-1 p-2 border rounded">
          {teams.map(t=> <option key={t.name+'b'} value={t.name}>{t.name}</option>)}
        </select>
      </div>
      <input type="datetime-local" value={date} onChange={e=>setDate(e.target.value)} className="w-full p-2 border rounded" />
      <button onClick={create} className="w-full bg-yellow-500 p-2 rounded">Create Match (Admin)</button>
    </div>
  );
}

function RecordResult({match, onSave}){
  const [scoreA, setScoreA] = useState(match.result?.scoreA||0);
  const [scoreB, setScoreB] = useState(match.result?.scoreB||0);
  const save = ()=>{ const winner = scoreA===scoreB? 'draw' : (scoreA>scoreB? match.teamA: match.teamB); onSave(match.id, {winner, scoreA, scoreB}); };
  return (
    <div className="flex flex-col">
      <input type="number" value={scoreA} onChange={e=>setScoreA(Number(e.target.value))} className="w-20 p-1 border rounded text-center" />
      <span className="text-center">-</span>
      <input type="number" value={scoreB} onChange={e=>setScoreB(Number(e.target.value))} className="w-20 p-1 border rounded text-center" />
      <button onClick={save} className="mt-1 px-2 py-1 bg-green-600 text-white rounded">Save</button>
    </div>
  );
}

function AnnouncementEditor({announcements, setAnnouncements}){
  const [text, setText] = useState('');
  const add = ()=>{ if(!text) return; setAnnouncements([text, ...announcements]); setText(''); };
  return (
    <div className="mt-2 space-y-2">
      <textarea value={text} onChange={e=>setText(e.target.value)} className="w-full p-2 border rounded" placeholder="Write announcement..." />
      <button onClick={add} className="px-3 py-1 bg-blue-600 text-white rounded">Post Announcement</button>
    </div>
  );
}
