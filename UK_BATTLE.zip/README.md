# UK BATTLE - Tournament App

This is a minimal React + Vite project for the UK BATTLE e-sports tournament manager.
It includes registration, teams, match scheduling, leaderboard, announcements, and import/export.

How to run (locally):
1. npm install
2. npm run dev
3. Open http://localhost:5173

Notes:
- Admin password (for demo) is: admin123 — change this in production.
- This project uses localStorage for data persistence.
